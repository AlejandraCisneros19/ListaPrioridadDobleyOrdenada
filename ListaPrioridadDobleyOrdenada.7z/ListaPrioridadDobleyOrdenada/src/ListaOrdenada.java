
public class ListaOrdenada {
    
    private NodoOrdenada ini;
    private NodoOrdenada fin;
    
    public ListaOrdenada(){
        ini=null;
        fin=null;
    }
    
    public boolean insertar(char v){
        NodoOrdenada nuevo = new NodoOrdenada(v);
        
        if(nuevo==null){
            return false;
        }
        if(ini==null && fin==null){
            ini=fin=nuevo;
            return true;
        }
        if(nuevo.valor>ini.valor){
            ini.ant=nuevo;
            nuevo.sig=ini;
            ini=nuevo;
            return true;
        }
        if(nuevo.valor<=fin.valor){
            fin.ant=nuevo;
            nuevo.ant=fin;
            fin=nuevo;
            return true;
        }
        NodoOrdenada t2=null;
        for(t2=fin.ant;nuevo.valor>t2.valor; t2=t2.ant){}
        t2.sig.ant=nuevo;
        nuevo.sig=t2.sig;
        t2.sig=nuevo;
        nuevo.ant=t2;
        return true;
    }
    
    public String mostrar(){
        if(ini==null && fin==null){
            return "LISTA VACIA";
        }
        return mostrar(ini);
    }
    
    private String mostrar(NodoOrdenada temp){
        if(temp==null){
            return "";
        }
        return temp.valor+"->"+mostrar(temp.sig);
    }
    
    public boolean eliminar(char v){
        if(ini==null && fin== null){
            return false;
        }
        if(ini==fin && ini!=null){
            if(ini.valor==v){
                ini=fin=null;
                return true;
            }
            return false;
        }
        //si eliminar esta en ini
        if(ini.valor==v){
            NodoOrdenada temp = ini.sig;
            temp.ant=null;
            ini.sig=null;
            ini=temp;
            return true;
        }
        //si eliminar esta en fin
        if(fin.valor==v){
            NodoOrdenada temp=fin.ant;
            temp.sig=null;
            fin.ant=null;
            fin=temp;
            return true;
        }
        //eliminar esta en medio
        for(NodoOrdenada temp=ini.sig; temp!=fin; temp=temp.sig){
            if(temp.valor==v){
                temp.ant.sig=temp.sig;
                temp.sig.ant=temp.ant;
                temp.ant=null;
                temp.sig=null;
                return true;
            }
        }
        return false;
    }
}


public class NodoOrdenada {
    
    char valor;
    NodoOrdenada sig;
    NodoOrdenada ant;
    
    public NodoOrdenada(char v){
        valor=v;
        sig=null;
        ant=null;
    }
    
}


public class NodoPrioridad {
    
    char valor;
    int prioridad;
    NodoPrioridad sig;
    NodoPrioridad ant;
    
    public NodoPrioridad(char v, int p){
        valor=v;
        prioridad=p;
        sig=null;
        ant=null;
        
    }
}

/*
 * @author 52311
 */
public class ListaPrioridadDoble {
    
    private NodoPrioridad ini;
    private NodoPrioridad fin;
    
    public ListaPrioridadDoble(){
        ini=null;
        fin=null;
    }
    
    public boolean insertar(char v, int p){
        NodoPrioridad nuevo = new NodoPrioridad(v,p);
        
        if(nuevo==null){
            return false;
        }
        if(ini==null && fin==null){
            ini=fin=nuevo;
            return true;
        }
        if(nuevo.prioridad>ini.prioridad){
            ini.ant=nuevo;
            nuevo.sig=ini;
            ini=nuevo;
            return true;
        }
        if(nuevo.prioridad<=fin.prioridad){
            fin.ant=nuevo;
            nuevo.ant=fin;
            fin=nuevo;
            return true;
        }
        NodoPrioridad t2=null;
        for(t2=fin.ant;nuevo.prioridad>t2.prioridad; t2=t2.ant){}
        t2.sig.ant=nuevo;
        nuevo.sig=t2.sig;
        t2.sig=nuevo;
        nuevo.ant=t2;
        return true;
    }
    
    public String mostrar(){
        if(ini==null && fin==null){
            return "LISTA VACIA";
        }
        return mostrar(ini);
    }
    
    private String mostrar(NodoPrioridad temp){
        if(temp==null){
            return "";
        }
        return temp.valor+"->"+mostrar(temp.sig);
    }
    
    public boolean eliminar(char v, int p){
        if(ini==null && fin== null){
            return false;
        }
        if(ini==fin && ini!=null){
            if(ini.valor==v && ini.prioridad==p){
                ini=fin=null;
                return true;
            }
            return false;
        }
        //si eliminar esta en ini
        if(ini.valor==v && ini.prioridad==p){
            NodoPrioridad temp = ini.sig;
            temp.ant=null;
            ini.sig=null;
            ini=temp;
            return true;
        }
        //si eliminar esta en fin
        if(fin.valor==v && fin.prioridad==p){
            NodoPrioridad temp=fin.ant;
            temp.sig=null;
            fin.ant=null;
            fin=temp;
            return true;
        }
        //eliminar esta en medio
        for(NodoPrioridad temp=ini.sig; temp!=fin; temp=temp.sig){
            if(temp.valor==v && temp.prioridad==p){
                temp.ant.sig=temp.sig;
                temp.sig.ant=temp.ant;
                temp.ant=null;
                temp.sig=null;
                return true;
            }
        }
        return false;
    }
    
}
